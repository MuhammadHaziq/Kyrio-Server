import express from "express";
import Modifier from "../../modals/items/Modifier";
import {
  MODIFIER_INSERT,
  MODIFIER_UPDATE,
  MODIFIER_DELETE,
} from "../../sockets/events";
const router = express.Router();

router.post("/", async (req, res) => {
  const { title, type, options, stores } = req.body;
  try {
    var typeName = type !== undefined ? type : "";
    var jsonOptions =
      typeof options !== "undefined" && options.length > 0
        ? options
        : [];
    var jsonStores =
      typeof stores !== "undefined" && stores.length > 0
        ? stores
        : [];
    const { _id, account } = req.authData;
    const countModifier = await Modifier.countDocuments();
    const newModifier = new Modifier({
      title: title,
      account: account,
      type: typeName,
      options: jsonOptions,
      stores: jsonStores,
      position: countModifier + 1,
      createdBy: _id,
    });
    const result = await newModifier.save();

    req.io.emit(MODIFIER_INSERT, { data: result, user: _id });

    res.status(201).json(result);
  } catch (error) {
    if (error.code === 11000) {
      res.status(400).json({ message: "Modifier Already Register" });
    } else {
      res.status(400).json({ message: error.message });
    }
  }
});

router.get("/:storeId", async (req, res) => {
  try {
    const { account } = req.authData;
    const { storeId } = req.params;
    let storeFilter = {};
    if (storeId !== "0") {
      storeFilter.stores = { $in: storeId };
    }
    storeFilter.account = account;
    storeFilter.deleted = 0;

    const result = await Modifier.find(storeFilter).populate('stores', ["_id","title"]).sort({ position: 1 });

    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.post("/getStoreModifiers", async (req, res) => {
  try {
    const { account } = req.authData;
    const { storeId } = req.body;
    const result = await Modifier.find({
      stores: { $in: storeId },
      account: account,
      deleted: 0,
    }).populate('stores', ["_id","title"]).sort({ postion: "asc" });
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.delete("/:ids", async (req, res) => {
  try {
    var { ids } = req.params;
    const { _id, account } = req.authData;
    ids = JSON.parse(ids);

    let del = await Modifier.updateMany(
      { _id: { $in: ids }, account: account },
      { $set: { deleted: 1, deletedAt: Date.now() } },
      {
        new: true,
        upsert: true,
      }
    );

    if (del.n > 0 && del.nModified > 0) {
      req.io.emit(MODIFIER_DELETE, { data: ids, user: _id });
    }

    res.status(200).json({ message: "deleted" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.patch("/update_position", async (req, res) => {
  try {
    let { modifier } = req.body;
    const { _id, account } = req.authData;
    await (modifier || []).map(async (item) => {
      const result = await Modifier.findOneAndUpdate(
        { _id: item.id, account: account },
        {
          $set: {
            position: item.position,
          },
        },
        {
          new: true,
          upsert: true, // Make this update into an upsert
        }
      );
      console.log(result)
    });

    let modifiersUpdated = await Modifier.find({ account: account }).populate('stores', ["_id","title"]).sort({
      position: "asc",
    });
    req.io.emit(MODIFIER_UPDATE, { data: modifiersUpdated, user: _id });

    res.status(200).json({ message: "Modifier Position Is Updated" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.patch("/:id", async (req, res) => {
  try {
    const { title, options, stores } = req.body;
    const { _id, account } = req.authData;
    const { id } = req.params;

    const result = await Modifier.findOneAndUpdate(
      { _id: id, account: account },
      {
        $set: {
          title: title,
          options: options,
          stores: stores,
        },
      },
      {
        new: true,
        upsert: true, // Make this update into an upsert
      }
    ).populate('stores', ["_id","title"]).sort({ position: 1 });

    req.io.emit(MODIFIER_UPDATE, { data: result, user: _id });

    res.status(200).json({ message: "Modifier Updated", data: result });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});
router.get("/row/:id", async (req, res) => {
  try {
    const { account } = req.authData;
    const { id } = req.params;
    let storeFilter = {};
    storeFilter.account = account;
    storeFilter._id = id;
    storeFilter.deleted = 0;
    const result = await Modifier.findOne(storeFilter).populate('stores', ["_id","title"]).sort({
      position: "asc",
    });
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
